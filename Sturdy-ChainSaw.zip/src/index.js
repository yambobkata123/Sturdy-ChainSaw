import express from 'express';
import handlebars from 'express-handlebars';
import mongoose from 'mongoose';
import cookieParser from 'cookie-parser';
import router from './routes/router.js';  // <-- add .js here
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;

// Handlebars setup
app.engine('.hbs', handlebars.engine({
  extname: '.hbs',
  defaultLayout: 'main',
  layoutsDir: path.join(__dirname, 'views/layouts'),
  partialsDir: path.join(__dirname, 'views/partials'),
}));
app.set('view engine', '.hbs');
app.set('views', path.join(__dirname, 'views'));

// Static resources (CSS, images, etc.)
app.use('/views', express.static(path.join(__dirname, 'views')));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Routes
app.use(router);

// MongoDB connection
mongoose.connect('mongodb://127.0.0.1:27017/carShowcase')
  .then(() => {
    app.listen(port, () => console.log(`✅ Server started at http://localhost:${port}`));
  })
  .catch(err => console.error('❌ DB connection error:', err.message));
