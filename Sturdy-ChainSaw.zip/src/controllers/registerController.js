import { Router } from 'express';
import User from '../schema/User.js';

const router = Router();

// GET /register - show registration form
router.get('/', (req, res) => {
  res.render('register', { error: null, formData: {} });
});

// POST /register - handle form submission
router.post('/', async (req, res) => {
  const { firstName, lastName, email, password, confirmPassword } = req.body;

  // Basic validation
  if (!firstName || !lastName || !email || !password || !confirmPassword) {
    return res.status(400).render('register', { error: 'All fields are required', formData: req.body });
  }

  if (password !== confirmPassword) {
    return res.status(400).render('register', { error: 'Passwords do not match', formData: req.body });
  }

  try {
    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).render('register', { error: 'Email is already registered', formData: req.body });
    }

    // Create new user
    const newUser = new User({ firstName, lastName, email, password });

    await newUser.save();

    // Optionally, auto-login the user:
    req.session.userId = newUser._id;

    // Redirect to homepage or dashboard after successful registration
    res.redirect('/');
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).render('register', { error: 'Server error, please try again later', formData: req.body });
  }
});

export default router;
