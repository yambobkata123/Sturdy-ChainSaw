import mongoose from 'mongoose';
import bcrypt from 'bcrypt';

const carSchema = new mongoose.Schema({
  model:        { type: String, required: true, trim: true },
  manufacturer: { type: String, required: true, trim: true },
  engine:       { type: String, required: true, trim: true },
  topSpeed:     { type: Number, required: true },
  image:        { type: String, required: true },  // URL or filename for car image
  description:  { type: String, required: true, trim: true },
  likes:        [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],  // array of User IDs
  owner:        { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
});

const Car = mongoose.model('Car', carSchema);
export default Car;
