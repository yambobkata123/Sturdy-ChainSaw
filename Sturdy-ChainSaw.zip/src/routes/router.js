import { Router } from 'express';
import homeController from '../controllers/homeController.js'; // default export
import registerController from '../controllers/registerController.js'; // default export
import loginController from '../controllers/loginController.js'; // default export

const router = Router();

router.use('/', homeController);           // home page
router.use('/auth/login', loginController); // login routes under /auth/login
router.use('/auth/register', registerController); // logout 

export default router;
